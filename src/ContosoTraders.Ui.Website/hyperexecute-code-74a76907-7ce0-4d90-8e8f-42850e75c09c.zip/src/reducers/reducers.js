import { combineReducers } from 'redux';

import login from './login.reducer';
// import theme from './theme.reducer';

export default combineReducers({ login });