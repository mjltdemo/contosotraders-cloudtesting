﻿global using MediatR;
global using Microsoft.AspNetCore.Mvc;
global using ContosoTraders.Api.Core;
global using ContosoTraders.Api.Core.Constants;
global using ContosoTraders.Api.Core.Controllers;
global using ContosoTraders.Api.Core.Models.Implementations.Dto;
global using ContosoTraders.Api.Core.Requests.Definitions;