﻿namespace ContosoTraders.Api.Core.Requests.Validators;

public class GetPopularProductsRequestValidator : AbstractValidator<GetPopularProductsRequest>
{
}