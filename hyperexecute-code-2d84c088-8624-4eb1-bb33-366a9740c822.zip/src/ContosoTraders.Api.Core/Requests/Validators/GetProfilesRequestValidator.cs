﻿namespace ContosoTraders.Api.Core.Requests.Validators;

public class GetProfilesRequestValidator : AbstractValidator<GetProfilesRequest>
{
}