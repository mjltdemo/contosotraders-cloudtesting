﻿namespace ContosoTraders.Api.Core.Requests.Validators;

public class GetProductsRequestValidator : AbstractValidator<GetProductsRequest>
{
}