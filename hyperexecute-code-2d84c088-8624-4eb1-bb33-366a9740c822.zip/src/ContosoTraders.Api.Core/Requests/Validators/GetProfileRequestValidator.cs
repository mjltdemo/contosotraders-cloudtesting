﻿namespace ContosoTraders.Api.Core.Requests.Validators;

public class GetProfileRequestValidator : AbstractValidator<GetProfileRequest>
{
}