﻿namespace ContosoTraders.Api.Core.Requests.Definitions;

public class GetProfilesRequest : IRequest<IActionResult>
{
}