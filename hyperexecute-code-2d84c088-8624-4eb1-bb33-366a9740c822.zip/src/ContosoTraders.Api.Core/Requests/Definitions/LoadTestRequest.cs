﻿namespace ContosoTraders.Api.Core.Requests.Definitions;

public class LoadTestRequest : IRequest<IActionResult>
{
}