﻿namespace ContosoTraders.Api.Core.Requests.Definitions;

public class GetPopularProductsRequest : IRequest<IActionResult>
{
}