﻿namespace ContosoTraders.Api.Core.Models.Implementations.Dao;

public class Brand
{
    public int Id { get; set; }
    public string Name { get; set; }
}