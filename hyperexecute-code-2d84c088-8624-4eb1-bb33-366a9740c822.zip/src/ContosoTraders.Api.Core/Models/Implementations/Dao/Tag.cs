﻿namespace ContosoTraders.Api.Core.Models.Implementations.Dao;

public class Tag
{
    public int Id { get; set; }
    public string Value { get; set; }
}