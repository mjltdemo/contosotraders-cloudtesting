﻿namespace ContosoTraders.Api.Core.Models.Implementations.Dto;

public class StockDto
{
    public int ProductId { get; set; }

    public int StockCount { get; set; }
}