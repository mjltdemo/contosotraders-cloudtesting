﻿namespace ContosoTraders.Api.Core.Repositories.Interfaces;

public interface IStockRepository : ICosmosGenericRepository<StockDao>
{
}