﻿namespace ContosoTraders.Api.Core.Repositories.Interfaces;

public interface ICartRepository : ICosmosGenericRepository<CartDao>
{
}