﻿namespace ContosoTraders.Api.Core.Constants;

public class AuthConstants
{
    public static readonly string DefaultJwtSigningKey = "Ta!lwindTraderssssssss";
}