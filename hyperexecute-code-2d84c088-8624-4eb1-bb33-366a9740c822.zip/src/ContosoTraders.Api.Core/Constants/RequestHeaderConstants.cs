﻿namespace ContosoTraders.Api.Core.Constants;

public class RequestHeaderConstants
{
    public const string HeaderNameUserEmail = "x-tt-email";
}