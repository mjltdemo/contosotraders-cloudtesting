export const FORM_EMAIL = '@@form/EMAIL';
export const SAVE_USER = '@@form/SUBMIT';
export const REMOVE_USER = '@@logout/CLICK';
export const THEME_CHANGE = 'THEME_CHANGE';
export const GET_QUANTITY = 'GET_QUANTITY';