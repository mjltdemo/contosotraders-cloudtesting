import React from 'react';
function MyAddressBook(props) {
    return ( 
        <div>
            Address
        </div>
    );
}

export default MyAddressBook;